#ifndef SHARED_TYPES_H
#define SHARED_TYPES_H

struct Position {
    float lat;
    float lon;
};

#endif